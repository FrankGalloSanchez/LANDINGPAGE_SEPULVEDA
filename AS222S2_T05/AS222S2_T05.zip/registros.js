const url = "http://localhost:3000/api/infoPer/";
let resultados = '';
const formArticulo = document.querySelector("form");
const NAMEPER = document.getElementById("NAMEPER");
const LASTNMPER = document.getElementById("LASTNMPER");
const CELUSPER = document.getElementById("CELUSPER");
const DIRECPER = document.getElementById("DIRECPER");
const EMAILPER = document.getElementById("EMAILPER");
const MSGPER = document.getElementById("MSGPER");


let option = '';


btnCrear.addEventListener('click', () => {
    console.log("Acción de listar activada");
    option = 'crear';
});


formArticulo.addEventListener('submit',
    (e) => {
    e.preventDefault();
    if (option == 'crear') {
        if( NAMEPER.value == "" || LASTNMPER.value == ""|| CELUSPER.value == ""|| DIRECPER.value== ""|| EMAILPER.value== ""|| MSGPER.value=="") {
            alert("Asegúrese de que todos los campos estén completos");
            return false;

        } else {
            console.log("Todos los campos están completos");
            fetch(
                url,
                {
                    method: 'POST',
                    headers: {
                        'content-Type':'application/json'
                    },
                    body: JSON.stringify(
                        {
                            NAMEPER: NAMEPER.value,
                            LASTNMPER: LASTNMPER.value,
                            CELUSPER: CELUSPER.value,
                            DIRECPER: DIRECPER.value,
                            EMAILPER: EMAILPER.value,
                            MSGPER: MSGPER.value
                        }
                    )
                }
            )
            .then(
                response => response.json()
            )
            .then(
                response => location.reload()
            );
        }
    } else if(opcion == 'editar'){
        console.log("Activado el ");
    }
}
);
//---------------------------------------calendario---------------------------------------
const MAIN_PATH = "http://localhost:3000/api/calendario";

const date = new Date();
let currentDate = date.getFullYear()+ "-"+ (date.getMonth() + 1)+ "-"+ date.getDate()
let currentDateFormatted = date.getDate()+ "/"+ (date.getMonth() + 1)+ "/"+ date.getFullYear();

let dates = fetch(
    MAIN_PATH + "calendario/"+ currentDate
).then(
    res => res.json()
).then(
    data => {
    console.log("Mostrando data: " +data)
    if (data != null) {
    document.getElementById("showDate").innerHTML = `<p>Hoy es ${currentDateFormatted} - ${data.NAMECAL}</p>`
    } else {
    document.getElementById("showDate").innerHTML = `<p>Hoy es ${currentDateFormatted}</p>`
    }
  }
);